import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, RefreshCw, Trophy } from 'lucide-react';

const SYMBOLS = ['🌱', '🧘', '🌊', '☀️', '🕊️', '💎', '🍀', '🍎'];
const CARDS = [...SYMBOLS, ...SYMBOLS];

export function MemoryGame({ onComplete }: { onComplete: () => void }) {
  const [cards, setCards] = useState(() => [...CARDS].sort(() => Math.random() - 0.5));
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  useEffect(() => {
    if (flipped.length === 2) {
      setMoves(m => m + 1);
      const [first, second] = flipped;
      if (cards[first] === cards[second]) {
        setMatched(prev => [...prev, first, second]);
        setFlipped([]);
      } else {
        const timer = setTimeout(() => setFlipped([]), 1000);
        return () => clearTimeout(timer);
      }
    }
  }, [flipped, cards]);

  useEffect(() => {
    if (matched.length === cards.length && cards.length > 0) {
      onComplete();
    }
  }, [matched, cards, onComplete]);

  const handleFlip = (idx: number) => {
    if (flipped.length < 2 && !flipped.includes(idx) && !matched.includes(idx)) {
      setFlipped(prev => [...prev, idx]);
    }
  };

  const reset = () => {
    setCards([...CARDS].sort(() => Math.random() - 0.5));
    setFlipped([]);
    setMatched([]);
    setMoves(0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Brain className="w-5 h-5 text-natural-teal" />
          <h3 className="font-serif font-bold text-natural-text">Foco Mental</h3>
        </div>
        <div className="text-[10px] font-black uppercase tracking-widest text-natural-text/40">
          Movimentos: {moves}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {cards.map((symbol, idx) => (
          <motion.button
            key={idx}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleFlip(idx)}
            className={`aspect-square rounded-2xl flex items-center justify-center text-2xl shadow-sm border transition-all ${
              flipped.includes(idx) || matched.includes(idx)
                ? 'bg-white border-natural-teal'
                : 'bg-natural-tan border-natural-border text-transparent'
            }`}
          >
            {(flipped.includes(idx) || matched.includes(idx)) ? symbol : '?'}
          </motion.button>
        ))}
      </div>

      {matched.length === cards.length && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-natural-teal/10 rounded-2xl flex items-center justify-between"
        >
          <div className="flex items-center space-x-2 text-natural-teal">
            <Trophy className="w-5 h-5" />
            <span className="text-xs font-black uppercase tracking-widest">Tudo Combinado!</span>
          </div>
          <button onClick={reset} className="p-2 text-natural-teal hover:bg-white rounded-full transition-colors">
            <RefreshCw className="w-4 h-4" />
          </button>
        </motion.div>
      )}
    </div>
  );
}
