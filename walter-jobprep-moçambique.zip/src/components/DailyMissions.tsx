import { motion, AnimatePresence } from 'motion/react';
import { Target, CheckCircle, Info, Sparkles, Coffee, BookOpen, Brain, Wind, Gamepad2, X, ShieldAlert } from 'lucide-react';
import { useState, useEffect } from 'react';
import { MemoryGame } from './MemoryGame';

interface Mission {
  id: string;
  title: string;
  category: 'mental' | 'physical' | 'habit' | 'game';
  icon: React.ReactNode;
}

const MISSIONS: Mission[] = [
  { id: 'm1', title: 'Respiração Quadrada (4x4)', category: 'mental', icon: <Wind className="w-5 h-5" /> },
  { id: 'm2', title: 'Beber água (O básico vence)', category: 'physical', icon: <Coffee className="w-5 h-5" /> },
  { id: 'm3', title: 'Treino de Foco: Memória', category: 'game', icon: <Gamepad2 className="w-5 h-5" /> },
  { id: 'm4', title: 'Eliminar 1 Gatilho Digital', category: 'habit', icon: <ShieldAlert className="w-5 h-5" /> },
  { id: 'm5', title: 'Anotar: Por que comecei?', category: 'mental', icon: <BookOpen className="w-5 h-5" /> },
  { id: 'm6', title: 'Caminhada de 10 minutos', category: 'physical', icon: <Sparkles className="w-5 h-5" /> },
];

export function DailyMissions() {
  const [completed, setCompleted] = useState<string[]>([]);
  const [showCelebration, setShowCelebration] = useState(false);
  const [activeGame, setActiveGame] = useState(false);
  const [reflectionAnswered, setReflectionAnswered] = useState(false);

  const dailyReflection = "Se o seu 'Eu' daqui a 5 anos te visse agora, o que ele diria sobre a sua escolha de hoje?";

  useEffect(() => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem(`missions_${today}`);
    const savedRef = localStorage.getItem(`reflection_${today}`);
    if (saved) setCompleted(JSON.parse(saved));
    if (savedRef) setReflectionAnswered(true);
  }, []);

  const handleReflection = () => {
    const today = new Date().toDateString();
    setReflectionAnswered(true);
    localStorage.setItem(`reflection_${today}`, 'true');
  };

  const toggleMission = (id: string) => {
    if (id === 'm3' && !completed.includes(id)) {
      setActiveGame(true);
      return;
    }

    const today = new Date().toDateString();
    const newCompleted = completed.includes(id)
      ? completed.filter(i => i !== id)
      : [...completed, id];
    
    setCompleted(newCompleted);
    localStorage.setItem(`missions_${today}`, JSON.stringify(newCompleted));

    if (newCompleted.length === MISSIONS.length) {
      setShowCelebration(true);
    }
  };

  const handleGameComplete = () => {
    setActiveGame(false);
    const today = new Date().toDateString();
    const newCompleted = [...completed, 'm3'];
    setCompleted(newCompleted);
    localStorage.setItem(`missions_${today}`, JSON.stringify(newCompleted));
    
    if (newCompleted.length === MISSIONS.length) {
      setShowCelebration(true);
    }
  };

  const progress = (completed.length / MISSIONS.length) * 100;

  return (
    <div className="space-y-6 pb-20">
      {/* Daily Reflection Section */}
      <motion.div 
        layout
        className={`glass-panel p-8 space-y-4 border-2 transition-all ${reflectionAnswered ? 'bg-natural-stone/50 border-natural-border' : 'border-natural-teal/30 bg-white shadow-xl rotate-1'}`}
      >
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${reflectionAnswered ? 'bg-natural-border text-natural-text/30' : 'bg-natural-teal text-white animate-bounce'}`}>
            <Sparkles className="w-4 h-4" />
          </div>
          <h3 className="text-[10px] font-black uppercase tracking-widest text-natural-teal">Reflexão do Dia</h3>
        </div>
        
        <p className={`font-serif text-xl italic leading-tight ${reflectionAnswered ? 'text-natural-text/30' : 'text-natural-text'}`}>
          &quot;{dailyReflection}&quot;
        </p>

        {!reflectionAnswered ? (
          <button 
            onClick={handleReflection}
            className="w-full bg-natural-teal text-white font-black py-4 rounded-xl text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all"
          >
            Refleti sobre isso
          </button>
        ) : (
          <div className="flex items-center space-x-2 text-natural-teal/40 text-[10px] font-black uppercase tracking-widest">
            <CheckCircle className="w-4 h-4" />
            <span>Mente focada</span>
          </div>
        )}
      </motion.div>

      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="font-serif font-black text-2xl text-natural-text">Missões Diárias</h2>
          <p className="text-[10px] uppercase tracking-widest font-bold text-natural-text/40">Fortaleça sua disciplina</p>
        </div>
        <div className="flex items-center space-x-2 bg-natural-teal/10 px-3 py-1 rounded-full">
          <Target className="w-4 h-4 text-natural-teal" />
          <span className="text-[10px] font-black font-mono text-natural-teal">
            {completed.length}/{MISSIONS.length}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 w-full bg-natural-tan rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          className="h-full bg-natural-teal"
        />
      </div>

      <div className="space-y-3">
        {MISSIONS.map((mission) => (
          <button
            key={mission.id}
            onClick={() => toggleMission(mission.id)}
            className={`w-full text-left glass-panel p-5 flex items-center justify-between transition-all group ${
              completed.includes(mission.id) ? 'bg-natural-teal/5 border-natural-teal/20' : 'hover:border-natural-teal/30'
            }`}
          >
            <div className="flex items-center space-x-4">
              <div className={`p-3 rounded-2xl transition-colors ${
                completed.includes(mission.id) ? 'bg-natural-teal text-white' : 'bg-natural-tan text-natural-text/40'
              }`}>
                {mission.icon}
              </div>
              <div>
                <h3 className={`font-bold transition-all ${
                  completed.includes(mission.id) ? 'text-natural-teal line-through' : 'text-natural-text'
                }`}>
                  {mission.title}
                </h3>
                <span className="text-[9px] uppercase tracking-tighter text-natural-text/40 font-black">
                  {mission.category === 'mental' ? 'Saúde Mental' : mission.category === 'physical' ? 'Físico' : mission.category === 'game' ? 'Mini-Game' : 'Hábito'}
                </span>
              </div>
            </div>
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
              completed.includes(mission.id) ? 'bg-natural-teal border-natural-teal scale-110' : 'border-natural-border'
            }`}>
              {completed.includes(mission.id) && <CheckCircle className="w-4 h-4 text-white" />}
            </div>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {activeGame && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[101] bg-natural-text/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              className="glass-panel w-full max-w-sm p-8 bg-white relative"
            >
              <button 
                onClick={() => setActiveGame(false)}
                className="absolute top-4 right-4 p-2 text-natural-text/20 hover:text-natural-text transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <MemoryGame onComplete={handleGameComplete} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="glass-panel p-6 bg-natural-teal text-white text-center space-y-4"
          >
            <Sparkles className="w-10 h-10 mx-auto" />
            <h3 className="font-serif font-bold text-xl italic">Tudo Concluído!</h3>
            <p className="text-sm opacity-90">Você provou ser mais forte que qualquer impulso hoje. Continue assim!</p>
            <button 
              onClick={() => setShowCelebration(false)}
              className="bg-white text-natural-teal px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest shadow-sm"
            >
              Uhuul!
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-start space-x-3 p-6 bg-natural-peach/30 rounded-[30px] border border-natural-peach/50">
        <Info className="w-5 h-5 text-natural-salmon flex-shrink-0 mt-1" />
        <p className="text-xs text-natural-text/70 leading-relaxed font-medium">
          Mantenha uma rotina firme. A disciplina é o antídoto para a recaída. Cada missão concluída é uma vitória contra o vício.
        </p>
      </div>
    </div>
  );
}
