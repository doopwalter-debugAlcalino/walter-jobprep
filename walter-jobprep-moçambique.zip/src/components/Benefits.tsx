import { motion } from 'motion/react';
import { TrendingUp, Heart, Wallet, Sparkles, Clock, ShieldCheck } from 'lucide-react';

export function Benefits() {
  // Mock data - in a real app these would be calculated based on user input
  const daysClean = 12;
  const costPerDay = 150; // Meticais or any currency
  const totalSaved = daysClean * costPerDay;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 pb-20"
    >
      <div className="space-y-2">
        <h2 className="font-serif font-black text-3xl text-natural-text">Sua Recompensa</h2>
        <p className="text-xs font-bold uppercase tracking-widest text-natural-text/40">O que você está ganhando de volta</p>
      </div>

      {/* Financial Benefits */}
      <div className="glass-panel p-8 space-y-6 bg-natural-teal/5 border-natural-teal/20">
        <div className="flex items-center justify-between">
          <div className="p-3 bg-natural-teal rounded-2xl text-white">
            <Wallet className="w-6 h-6" />
          </div>
          <div className="text-right">
            <span className="text-[10px] font-black uppercase tracking-widest text-natural-text/40">Economia Total</span>
            <p className="font-serif font-black text-3xl text-natural-teal">{totalSaved.toLocaleString()} MT</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <h4 className="text-xs font-black uppercase tracking-widest text-natural-text/60">O que você pode fazer com este valor:</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-natural-border text-center space-y-2">
              <span className="text-xl">🛒</span>
              <p className="text-[10px] font-bold text-natural-text/60">Rancho Semanal</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-natural-border text-center space-y-2">
              <span className="text-xl">🎁</span>
              <p className="text-[10px] font-bold text-natural-text/60">Presente Especial</p>
            </div>
          </div>
        </div>
      </div>

      {/* Health/Emotional Benefits */}
      <div className="grid grid-cols-1 gap-4">
        <BenefitCard 
          icon={<Heart className="w-5 h-5" />}
          title="Saúde Cardíaca"
          desc="Seu coração bate mais calmo e sua pressão estável."
          progress={85}
          color="text-natural-salmon"
        />
        <BenefitCard 
          icon={<Clock className="w-5 h-5" />}
          title="Tempo de Vida"
          desc="Você ganhou +48h de vida consciente até agora."
          progress={60}
          color="text-natural-teal"
        />
        <BenefitCard 
          icon={<ShieldCheck className="w-5 h-5" />}
          title="Autoestima"
          desc="A confiança de que você é o dono do seu destino."
          progress={45}
          color="text-natural-peach"
        />
      </div>

      <div className="p-10 bg-natural-teal text-white rounded-[40px] text-center space-y-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <TrendingUp className="w-32 h-32" />
        </div>
        <Sparkles className="w-12 h-12 text-white/40 mx-auto" />
        <div className="space-y-2 relative z-10">
          <h3 className="font-serif italic text-2xl">Você é um investimento que vale a pena.</h3>
          <p className="text-sm text-white/80 font-medium">Cada dia sem o vício é um depósito na sua conta de felicidade, saúde e um futuro próspero para você e sua família.</p>
        </div>
        <div className="pt-4 flex justify-center space-x-2">
            {[1,2,3,4,5].map(i => <div key={i} className="w-2 h-2 bg-white/40 rounded-full" />)}
        </div>
      </div>
    </motion.div>
  );
}

function BenefitCard({ icon, title, desc, progress, color }: { icon: React.ReactNode; title: string; desc: string; progress: number; color: string }) {
  return (
    <div className="glass-panel p-6 flex flex-col space-y-4">
      <div className="flex items-center space-x-4">
        <div className={`p-3 bg-natural-tan rounded-xl ${color}`}>
          {icon}
        </div>
        <div>
          <h4 className="font-bold text-natural-text">{title}</h4>
          <p className="text-xs text-natural-text/50 font-medium">{desc}</p>
        </div>
      </div>
      <div className="h-1.5 w-full bg-natural-tan rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          className={`h-full ${color.replace('text-', 'bg-')}`}
        />
      </div>
    </div>
  );
}
