import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

export function Disclaimer() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('alivio_disclaimer_accepted');
    if (!accepted) {
      setIsOpen(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('alivio_disclaimer_accepted', 'true');
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-natural-text/40 backdrop-blur-sm"
        >
          <motion.div 
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            className="glass-panel max-w-md w-full p-8 space-y-6 shadow-2xl"
          >
            <div className="flex items-center space-x-3 text-natural-salmon">
              <AlertTriangle className="w-8 h-8" />
              <h2 className="font-serif font-black text-2xl uppercase tracking-tight">Aviso Importante</h2>
            </div>
            
            <div className="space-y-4 text-natural-text/80 text-sm leading-relaxed">
              <p>
                O **Alívio** é uma ferramenta de apoio emocional e organizacional para ajudar na sua jornada de superação.
              </p>
              <p className="font-bold text-natural-text">
                Este aplicativo NÃO substitui o aconselhamento médico profissional, diagnóstico ou tratamento.
              </p>
              <p>
                Sempre procure o conselho de seu médico, psicólogo ou outro provedor de saúde qualificado para qualquer dúvida sobre uma condição médica ou vício.
              </p>
              <p className="italic text-xs">
                Em caso de emergência ou risco à vida, entre em contato imediatamente com os serviços de emergência (Ligue 112).
              </p>
            </div>

            <button 
              onClick={handleAccept}
              className="w-full bg-natural-teal text-white font-bold py-4 rounded-2xl flex items-center justify-center space-x-2 shadow-lg hover:scale-[1.02] transition-all"
            >
              <CheckCircle className="w-5 h-5" />
              <span>Eu entendo e desejo continuar</span>
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
