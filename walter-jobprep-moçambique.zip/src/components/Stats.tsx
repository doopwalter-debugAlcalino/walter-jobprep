import { motion } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { Calendar, TrendingUp, Trophy, Flame } from 'lucide-react';

const data = [
  { day: 'Seg', cravings: 8, mood: 2 },
  { day: 'Ter', cravings: 6, mood: 3 },
  { day: 'Qua', cravings: 7, mood: 4 },
  { day: 'Qui', cravings: 4, mood: 6 },
  { day: 'Sex', cravings: 3, mood: 7 },
  { day: 'Sab', cravings: 2, mood: 8 },
  { day: 'Dom', cravings: 1, mood: 9 },
];

export function Stats() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 pb-10"
    >
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-3xl font-bold text-natural-text">Seu Panorama</h2>
        <div className="flex items-center space-x-2 bg-natural-tan px-4 py-2 rounded-full border border-natural-border shadow-sm">
          <Calendar className="w-4 h-4 text-natural-teal" />
          <span className="text-xs font-black uppercase tracking-widest text-natural-teal">Última Semana</span>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-panel p-6 flex flex-col items-center justify-center space-y-2">
          <Flame className="w-8 h-8 text-natural-salmon animate-pulse" />
          <span className="text-3xl font-serif text-natural-text">12</span>
          <span className="text-[10px] font-bold uppercase tracking-widest text-natural-text/40">Dias Limpos</span>
        </div>
        <div className="glass-panel p-6 flex flex-col items-center justify-center space-y-2">
          <Trophy className="w-8 h-8 text-natural-teal" />
          <span className="text-3xl font-serif text-natural-text">24h</span>
          <span className="text-[10px] font-bold uppercase tracking-widest text-natural-text/40">Recorde Atual</span>
        </div>
      </div>

      {/* Cravings Chart */}
      <div className="glass-panel p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif font-bold text-lg text-natural-text flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-natural-teal" />
            Nível de Fissura
          </h3>
          <span className="text-[10px] bg-natural-peach text-natural-salmon px-2 py-0.5 rounded-full font-bold">EM QUEDA</span>
        </div>
        
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorCravings" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-natural-teal)" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="var(--color-natural-teal)" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-natural-border)" />
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: 'var(--color-natural-text)', fontSize: 10, fontWeight: 700 }}
              />
              <YAxis hide domain={[0, 10]} />
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '16px', 
                  border: 'none', 
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                  fontSize: '12px'
                }}
              />
              <Area 
                type="monotone" 
                dataKey="cravings" 
                stroke="var(--color-natural-teal)" 
                strokeWidth={3} 
                fillOpacity={1} 
                fill="url(#colorCravings)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <p className="text-[10px] text-center font-bold text-natural-text/40 uppercase tracking-widest">
            Sua vontade diminuiu 40% em relação à segunda-feira
        </p>
      </div>

      {/* Mood correlation */}
      <div className="glass-panel p-6 space-y-4">
        <h3 className="font-serif font-bold text-lg text-natural-text">Humor vs Estabilidade</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-natural-border)" />
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: 'var(--color-natural-text)', fontSize: 10, fontWeight: 700 }}
              />
              <Tooltip />
              <Line type="monotone" dataKey="mood" stroke="var(--color-natural-peach)" strokeWidth={3} dot={{ r: 4, fill: "var(--color-natural-salmon)" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </motion.div>
  );
}
