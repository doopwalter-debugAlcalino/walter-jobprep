import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wind, Shield, CheckCircle2, ChevronRight, Waves, Anchor, Eye } from 'lucide-react';

export function UrgeSurfer() {
  const [step, setStep] = useState<'intro' | 'breathing' | 'grounding' | 'complete'>('intro');
  const [breathingPhase, setBreathingPhase] = useState<'inspire' | 'hold' | 'expire' | 'wait'>('inspire');
  const [timer, setTimer] = useState(4);
  const [groundingItem, setGroundingItem] = useState(0);

  const groundingSteps = [
    { label: "5 Coisas que você vê", icon: <Eye />, detail: "Observe as cores e formas ao seu redor." },
    { label: "4 Coisas que você toca", icon: <Waves />, detail: "Sinta a textura da sua roupa ou pele." },
    { label: "3 Coisas que você ouve", icon: <Anchor />, detail: "Feche os olhos e isole os sons distantes." },
    { label: "1 Sensação interna", icon: <Shield />, detail: "Perceba seus pés tocando o chão." },
  ];

  // Breathing loop
  useEffect(() => {
    if (step !== 'breathing') return;

    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          // Transition phase
          setBreathingPhase((current) => {
            if (current === 'inspire') { setTimer(4); return 'hold'; }
            if (current === 'hold') { setTimer(4); return 'expire'; }
            if (current === 'expire') { setTimer(4); return 'wait'; }
            setTimer(4); return 'inspire';
          });
          return 4;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [step, breathingPhase]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="h-full flex flex-col items-center justify-center py-4"
    >
      <AnimatePresence mode="wait">
        {step === 'intro' && (
          <motion.div 
            key="intro"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="text-center space-y-10 max-w-sm"
          >
            <div className="relative group">
              <div className="absolute -inset-4 bg-natural-teal/10 rounded-full blur-2xl group-hover:bg-natural-teal/20 transition-all" />
              <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm border border-natural-border relative overflow-hidden">
                <Waves className="w-16 h-16 text-natural-teal animate-bounce" style={{ animationDuration: '3s' }} />
                <motion.div 
                  animate={{ y: [0, -40, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute bottom-0 w-full h-8 bg-natural-teal/10"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <h2 className="font-serif font-bold text-4xl text-natural-text leading-tight">
                Surfe na onda da <span className="text-natural-teal italic">fissura.</span>
              </h2>
              <p className="text-natural-text/70 font-medium">
                A vontade intensa é como uma onda. Ela cresce, atinge um pico e depois desce. Vamos passar por isso juntos agora.
              </p>
            </div>
            <button 
              onClick={() => setStep('breathing')}
              className="w-full bg-natural-teal text-white font-bold py-5 rounded-[30px] flex items-center justify-center space-x-2 shadow-xl hover:scale-105 transition-transform"
            >
              <span>Começar Respiração</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </motion.div>
        )}

        {step === 'breathing' && (
          <motion.div 
            key="breathing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center space-y-12 w-full max-w-xs"
          >
            <div className="relative flex items-center justify-center">
              {/* Dynamic Aura */}
              <motion.div 
                animate={{ 
                  scale: breathingPhase === 'inspire' ? [1, 1.4, 1.6] : (breathingPhase === 'expire' ? [1.6, 1.2, 1] : (breathingPhase === 'hold' ? 1.6 : 1)),
                  opacity: breathingPhase === 'inspire' ? 0.4 : (breathingPhase === 'expire' ? 0.2 : 0.4)
                }}
                transition={{ duration: 4, ease: "easeInOut" }}
                className="absolute w-64 h-64 bg-natural-teal rounded-full blur-3xl"
              />
              
              <motion.div 
                animate={{ 
                  scale: breathingPhase === 'inspire' ? 1.5 : (breathingPhase === 'expire' ? 1 : (breathingPhase === 'hold' ? 1.5 : 1))
                }}
                transition={{ duration: 4, ease: "easeInOut" }}
                className="w-56 h-56 bg-white rounded-full flex items-center justify-center border-8 border-natural-border shadow-xl relative z-10"
              >
                <div className="text-center">
                  <motion.p 
                    key={breathingPhase}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-natural-text font-serif italic text-2xl"
                  >
                    {breathingPhase === 'inspire' && 'Inspire'}
                    {breathingPhase === 'hold' && 'Segure'}
                    {breathingPhase === 'expire' && 'Expire'}
                    {breathingPhase === 'wait' && 'Pausa'}
                  </motion.p>
                  <p className="text-5xl font-serif font-bold text-natural-teal">{timer}</p>
                </div>
              </motion.div>
            </div>

            <div className="space-y-6">
              <p className="text-natural-text/50 font-bold uppercase tracking-widest text-[10px]">Acompanhe o movimento visual</p>
              <div className="flex justify-center space-x-2">
                {['inspire', 'hold', 'expire', 'wait'].map((p) => (
                  <div 
                    key={p} 
                    className={`w-2 h-2 rounded-full transition-all ${breathingPhase === p ? 'bg-natural-teal w-6' : 'bg-natural-border'}`}
                  />
                ))}
              </div>
              <button 
                onClick={() => setStep('grounding')}
                className="w-full bg-natural-tan text-natural-teal font-bold py-4 rounded-2xl border border-natural-border hover:bg-white transition-all shadow-sm"
              >
                Próximo: Ancoragem
              </button>
              <button 
                onClick={() => setStep('complete')}
                className="text-natural-salmon text-xs font-black uppercase tracking-widest hover:scale-110 transition-transform"
              >
                Já me sinto melhor
              </button>
            </div>
          </motion.div>
        )}

        {step === 'grounding' && (
          <motion.div 
            key="grounding"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="text-center space-y-10 max-w-sm"
          >
            <div className="flex flex-col items-center space-y-4">
              <div className="w-20 h-20 bg-natural-peach rounded-3xl flex items-center justify-center shadow-sm text-natural-salmon">
                {groundingSteps[groundingItem].icon}
              </div>
              <h2 className="font-serif font-bold text-2xl text-natural-text">{groundingSteps[groundingItem].label}</h2>
              <p className="text-natural-text/60 font-medium px-4">{groundingSteps[groundingItem].detail}</p>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {groundingSteps.map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full ${i <= groundingItem ? 'bg-natural-salmon' : 'bg-natural-border'}`} />
              ))}
            </div>

            <button 
              onClick={() => {
                if (groundingItem < groundingSteps.length - 1) {
                  setGroundingItem(prev => prev + 1);
                } else {
                  setStep('complete');
                }
              }}
              className="w-full bg-natural-salmon text-white font-bold py-5 rounded-[30px] shadow-lg hover:scale-105 transition-all"
            >
              {groundingItem < groundingSteps.length - 1 ? 'Próximo' : 'Concluir'}
            </button>
          </motion.div>
        )}

        {step === 'complete' && (
          <motion.div 
            key="complete"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-8"
          >
            <div className="relative">
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }} 
                transition={{ repeat: Infinity, duration: 4 }}
                className="absolute inset-0 bg-natural-teal/20 rounded-full blur-2xl" 
              />
              <div className="w-24 h-24 bg-natural-tan rounded-full flex items-center justify-center mx-auto border border-natural-sand relative z-10">
                <CheckCircle2 className="w-12 h-12 text-natural-teal" />
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="font-serif font-bold text-4xl text-natural-text italic">Você conseguiu.</h2>
              <p className="text-natural-text/70 font-medium">A onda passou. Você é mais forte do que a vontade.</p>
            </div>
            <button 
              onClick={() => {
                setStep('intro');
                setGroundingItem(0);
              }}
              className="px-12 bg-natural-teal text-white font-bold py-4 rounded-[30px] shadow-xl hover:scale-105 transition-transform"
            >
              Voltar ao Início
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
