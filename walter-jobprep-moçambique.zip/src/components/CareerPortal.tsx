import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Briefcase, CreditCard, Layout, Star, ArrowRight, CheckCircle2, Search, ExternalLink, MessageSquare, User, Bot, Loader2, X, Plus, Send, Trophy, Users, TrendingUp, MapPin } from 'lucide-react';
import { therapeuticCoach } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import confetti from 'canvas-confetti';

type Message = {
  role: 'user' | 'model';
  parts: { text: string }[];
};

export function CareerPortal() {
  const [view, setView] = useState<'home' | 'cv-check' | 'interview' | 'payment' | 'templates' | 'select-company'>('home');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [selectedPersona, setSelectedPersona] = useState<'walter' | 'maria' | 'antonio' | 'delfina'>('walter');
  const [selectedCompany, setSelectedCompany] = useState<string>('');
  const [companySearch, setCompanySearch] = useState('');

  const suggestedCompanies = [
    'Recheio (Maputo)', 'Mozal', 'CMC', 'TotalEnergies', 'BIM', 'Sasol', 'Vulcan', 'Porto de Maputo', 'Mecula', 'Shoprite', 'KFC Moçambique', 'Coca-Cola (Matola)', 'EDM', 'HCB (Songo)'
  ];

  const templates = [
    { id: 'executivo', name: 'Executivo Moderno', desc: 'Ideal para cargos de liderança e gestão.', image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&q=80&w=400', color: 'border-blue-500' },
    { id: 'criativo', name: 'Criativo Minimalista', desc: 'Perfeito para Marketing, Design e Vendas.', image: 'https://images.unsplash.com/photo-1626197031507-c17099753214?auto=format&fit=crop&q=80&w=400', color: 'border-purple-500' },
    { id: 'academico', name: 'Sénior Académico', desc: 'Focado em histórico detalhado e formações.', image: 'https://images.unsplash.com/photo-1544652478-6653e09f18a2?auto=format&fit=crop&q=80&w=400', color: 'border-slate-500' },
    { id: 'jovem', name: 'Jovem Talento', desc: 'Especial para quem busca o primeiro emprego.', image: 'https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?auto=format&fit=crop&q=80&w=400', color: 'border-emerald-500' },
  ];

  const selectTemplate = (templateId: string) => {
    setSelectedTemplate(templateId);
    setSelectedPersona('maria');
    setMessages([{
      role: 'model',
      parts: [{ text: `Excelente escolha! O template **${templates.find(t => t.id === templateId)?.name}** vai destacar muito o seu perfil.\n\nPara eu montar o seu CV agora, por favor envie seus dados básicos:\n\n1. Nome Completo e Contactos\n2. Últimas 2 experiências profissionais\n3. Sua formação principal\n\nEu cuidarei de toda a escrita estratégica!` }]
    }]);
    setView('interview');
  };
  const [cvText, setCvText] = useState('');
  const [feedback, setFeedback] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Chat state for interview
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const personas = {
    walter: { name: 'Walter Recrutador', role: 'Entrevista Profissional', icon: <Briefcase className="w-6 h-6" />, color: 'bg-blue-600', greeting: 'Olá! Sou o **Walter**. Estou aqui para ajudar-te a brilhar na tua próxima entrevista. Para qual vaga pretendes concorrer?' },
    maria: { name: 'Maria Escrita', role: 'Especialista em CV Prático', icon: <FileText className="w-6 h-6" />, color: 'bg-purple-600', greeting: 'Olá! Sou a **Maria**. Vamos valorizar a tua experiência, seja ela qual for. Podes enviar o teu texto ou pedir dicas para o teu CV?' },
    antonio: { name: 'António Técnico', role: 'Especialista Prático', icon: <Bot className="w-6 h-6" />, color: 'bg-slate-700', greeting: 'Saudações, sou o António. Vamos direto ao ponto: o que é que tu sabes fazer na prática e para que cargo estás a olhar?' },
    delfina: { name: 'Delfina Psicóloga', role: 'Confiança e Postura', icon: <Star className="w-6 h-6" />, color: 'bg-emerald-600', greeting: 'Olá, sou a **Delfina**. Lembra-te: o teu valor vai além do diploma. Como te sentes em relação à tua busca por emprego hoje?' }
  };

  useEffect(() => {
    if (view === 'interview' && messages.length === 0) {
      setMessages([{
        role: 'model',
        parts: [{ text: personas[selectedPersona].greeting }]
      }]);
    }
  }, [view, selectedPersona, messages.length]);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages]);

  const handleSendInterview = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', parts: [{ text: input }] };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await therapeuticCoach.getResponse(input, messages, selectedPersona, selectedCompany || undefined);
      setMessages(prev => [...prev, { role: 'model', parts: [{ text: responseText }] }]);
      
      // Trigger confetti if the AI says they passed
      if (responseText.toLowerCase().includes('aprovado') || responseText.toLowerCase().includes('parabéns')) {
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#2563eb', '#4f46e5', '#10b981']
        });
      }
    } catch (error: any) {
      setMessages(prev => [...prev, { 
        role: 'model', 
        parts: [{ text: `❌ **Erro**: ${error.message || 'Erro desconhecido ao contactar o Walter.'}` }] 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleValidateCV = async () => {
    if (!cvText.trim()) return;
    setIsLoading(true);
    try {
      const responseText = await therapeuticCoach.getResponse(
        `Analise este CV para o mercado de Moçambique e dê 3 ideias de melhoria crítica seguindo os padrões profissionais: \n\n${cvText}`,
        [],
        'maria'
      );
      setFeedback(responseText);
    } catch (error: any) {
      setFeedback(`❌ **Erro**: ${error.message || 'Não foi possível contactar a Maria.'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const startInterview = (personaId: 'walter' | 'maria' | 'antonio' | 'delfina') => {
    setSelectedPersona(personaId);
    if (personaId === 'walter') {
      setView('select-company');
    } else {
      setMessages([{ role: 'model', parts: [{ text: personas[personaId].greeting }] }]);
      setView('interview');
    }
  };

  const startCompanyInterview = (companyName: string) => {
    setSelectedCompany(companyName);
    setMessages([{ 
      role: 'model', 
      parts: [{ text: `Olá! Sou o **Walter**. O processo de recrutamento para a **${companyName}** exige seriedade e competência. Estás pronto para começarmos? Para que vaga específica estás a concorrer nesta empresa?` }] 
    }]);
    setView('interview');
  };

  return (
    <div className="min-h-screen bg-[#0f172a] font-sans text-slate-100">
      {/* Header */}
      <header className="bg-slate-900/50 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]">
            <Briefcase className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tight text-white">Walter JobPrep</span>
        </div>
        <nav className="hidden md:flex space-x-6 text-sm font-medium text-slate-400">
          <button onClick={() => setView('home')} className="hover:text-blue-400 transition-colors">Início</button>
          <button onClick={() => setView('cv-check')} className="hover:text-blue-400 transition-colors">Validar CV</button>
          <button onClick={() => setView('templates')} className="hover:text-blue-400 transition-colors">Templates</button>
        </nav>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="text-center space-y-4 max-w-2xl mx-auto">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="inline-block px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider mb-4"
                >
                  <TrendingUp className="inline-block w-3 h-3 mr-1 mb-0.5" /> O Futuro do Trabalho em Moçambique
                </motion.div>
                <h1 className="text-4xl md:text-6xl font-black text-white leading-tight">
                  Prepara-te para o <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">Sucesso Profissional</span>
                </h1>
                <p className="text-slate-400 text-lg md:text-xl">
                  Seja tu um graduado ou um trabalhador prático, ajudamos-te a conseguir as melhores oportunidades em qualquer província.
                </p>
                
                <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-medium text-slate-500 py-4">
                  <div className="flex items-center"><Users className="w-4 h-4 mr-1 text-blue-500" /> +5.000 Moçambicanos preparados</div>
                  <div className="flex items-center"><Trophy className="w-4 h-4 mr-1 text-yellow-500" /> 85% taxa de aprovação</div>
                  <div className="flex items-center"><MapPin className="w-4 h-4 mr-1 text-red-500" /> Vagas de Maputo a Palma</div>
                </div>

                <div className="pt-8">
                  <h2 className="text-xl font-bold mb-8 text-slate-200 flex items-center justify-center">
                    <span className="h-px w-8 bg-slate-700 mr-4"></span>
                    Com quem queres treinar hoje?
                    <span className="h-px w-8 bg-slate-700 ml-4"></span>
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {Object.entries(personas).map(([id, p]) => (
                      <button 
                        key={id}
                        onClick={() => startInterview(id as any)}
                        className="group bg-slate-800/40 p-6 rounded-2xl border border-slate-700 hover:border-blue-500/50 hover:bg-slate-800/60 transition-all text-left space-y-4 relative overflow-hidden shadow-lg"
                      >
                        <div className={`w-12 h-12 ${p.color} text-white rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                          {p.icon}
                        </div>
                        <div>
                          <h3 className="font-bold text-white group-hover:text-blue-400 transition-colors text-lg">{p.name}</h3>
                          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">{p.role}</p>
                        </div>
                        <div className="absolute right-4 bottom-4 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                          <ArrowRight className="w-5 h-5 text-blue-400" />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <p className="text-center text-slate-500 text-sm font-bold uppercase tracking-widest">Treinamento para todos os sectores</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {['Mineração', 'Construção', 'Energia (Gás/Petróleo)', 'Logística', 'Agricultura', 'Turismo', 'Banca', 'Secretariado', 'Serviços Gerais'].map((sector) => (
                      <span key={sector} className="px-3 py-1 rounded-full bg-slate-800/40 border border-slate-700 text-slate-400 text-xs">
                        {sector}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <FeatureCard 
                  dark
                  icon={<FileText className="text-blue-400" />}
                  title="Validação de CV"
                  desc="Analisamos o teu perfil e sugerimos melhorias para o mercado real de Moçambique."
                />
                <button onClick={() => setView('templates')} className="block text-left w-full group">
                  <FeatureCard 
                    dark
                    icon={<Layout className="text-purple-400" />}
                    title="Templates Profissionais"
                    desc="Designs de alto impacto (Canva Style) prontos para impressionar qualquer patrão."
                  />
                </button>
                <FeatureCard 
                  dark
                  icon={<MessageSquare className="text-emerald-400" />}
                  title="Suporte Prático"
                  desc="Dicas para vagas operativas e corporativas. Aprendas a falar com confiança."
                />
              </div>

              {/* Statistics/Ticker Section */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-8 mt-12 grid md:grid-cols-4 gap-8">
                <div className="text-center space-y-1">
                  <p className="text-3xl font-black text-white">400+</p>
                  <p className="text-xs font-bold text-slate-500 uppercase">Empresas Mapeadas</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-3xl font-black text-blue-400">24/7</p>
                  <p className="text-xs font-bold text-slate-500 uppercase">Treino Disponível</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-3xl font-black text-purple-400">100%</p>
                  <p className="text-xs font-bold text-slate-500 uppercase">Moz Style</p>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-3xl font-black text-emerald-400">Grátis</p>
                  <p className="text-xs font-bold text-slate-500 uppercase">Simulação Inicial</p>
                </div>
              </div>

              {/* Canva Section replacement */}
              <div className="bg-slate-900 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
                <div className="relative z-10 space-y-6 max-w-lg">
                  <div className="flex items-center space-x-2 text-blue-400 font-bold uppercase tracking-widest text-xs">
                    <Star className="w-4 h-4 fill-current" />
                    <span>Premium BOOM</span>
                  </div>
                  <h2 className="text-3xl font-bold">Os melhores CVs profissionais são Walter JobPrep Premium</h2>
                  <p className="text-slate-400">
                    Não perca tempo com Word. Use a estética de alto impacto do Walter JobPrep para se destacar visualmente e passar nos sistemas automáticos (ATS).
                  </p>
                  <a 
                    href="https://www.canva.com/resumes/templates/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-white font-bold hover:underline"
                  >
                    Ver Templates Profissionais <ExternalLink className="ml-2 w-4 h-4" />
                  </a>
                </div>
                <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-blue-600/20 to-transparent hidden md:block" />
              </div>
            </motion.div>
          )}

          {view === 'cv-check' && (
            <motion.div 
              key="cv"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-3xl mx-auto space-y-6"
            >
              <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 shadow-xl space-y-4">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-2xl font-bold text-white">Analista de Carreira IA</h2>
                  <button onClick={() => setView('home')} className="text-slate-400 hover:text-white text-sm flex items-center">
                    <X className="w-4 h-4 mr-1" /> Voltar
                  </button>
                </div>
                <p className="text-slate-400 text-sm">Cole o texto do seu CV abaixo para uma análise profunda feita pela Maria.</p>
                <textarea 
                  value={cvText}
                  onChange={(e) => setCvText(e.target.value)}
                  placeholder="Ex: Nome, Experiência em ajudante de obras, Experiência em motorista..."
                  className="w-full h-64 p-4 rounded-xl border border-slate-700 bg-slate-900 focus:ring-2 focus:ring-blue-600 outline-none text-slate-200 placeholder:text-slate-600"
                />
                <button 
                  disabled={isLoading || !cvText}
                  onClick={handleValidateCV}
                  className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold disabled:opacity-50 flex items-center justify-center hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/20"
                >
                  {isLoading ? "A Maria está a analisar..." : "Analisar CV Grátis"}
                </button>
              </div>

              {feedback && (
                <div className="bg-slate-800 rounded-2xl p-8 border border-blue-500/30 shadow-2xl space-y-4 animate-in fade-in slide-in-from-bottom-4">
                  <div className="flex items-center space-x-2 text-blue-400 font-bold">
                    <CheckCircle2 className="w-5 h-5" />
                    <span>Dicas da Maria JobPrep</span>
                  </div>
                  <div className="prose prose-invert prose-slate max-w-none">
                    <div className="whitespace-pre-wrap font-sans text-slate-300 leading-relaxed">
                      {feedback}
                    </div>
                  </div>
                  <div className="pt-6 border-t border-slate-700 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                      <p className="font-bold text-white">Queres o CV Profissional Pronto?</p>
                      <p className="text-sm text-slate-400">Nossa IA reformata tudo para o padrão de alto impacto.</p>
                    </div>
                    <button 
                      onClick={() => setView('payment')}
                      className="bg-white text-slate-900 px-8 py-3 rounded-xl font-bold flex items-center hover:bg-slate-200 transition-all"
                    >
                      <CreditCard className="mr-2 w-5 h-5" /> Obter CV Premium (500 MT)
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {view === 'select-company' && (
            <motion.div 
              key="select-company"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-2xl mx-auto space-y-8"
            >
              <div className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600/20 text-blue-400 rounded-2xl mb-2">
                  <Search className="w-8 h-8" />
                </div>
                <h2 className="text-3xl font-bold text-white">Onde queres trabalhar?</h2>
                <p className="text-slate-400 text-lg text-balance">Digita o nome da empresa e a localização (opcional) para o Walter personalizar a tua simulação.</p>
              </div>

              <div className="bg-slate-800/50 p-8 rounded-3xl border border-slate-700 shadow-2xl space-y-6">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
                  <input 
                    type="text"
                    value={companySearch}
                    onChange={(e) => setCompanySearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && companySearch && startCompanyInterview(companySearch)}
                    placeholder="Ex: Recheio de Nampula, Vale, Porto da Beira..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-4">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Sugestões Populares</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestedCompanies.map((c) => (
                      <button 
                        key={c}
                        onClick={() => startCompanyInterview(c)}
                        className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:border-blue-500 hover:text-white transition-all text-sm"
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>

                <button 
                  disabled={!companySearch}
                  onClick={() => startCompanyInterview(companySearch)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-900/40 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  <span>Iniciar Entrevista Personalizada</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>

              <div className="text-center">
                <button onClick={() => setView('home')} className="text-slate-400 hover:text-white flex items-center justify-center mx-auto transition-colors">
                  <X className="w-4 h-4 mr-1" /> Cancelar e Voltar
                </button>
              </div>
            </motion.div>
          )}

          {view === 'templates' && (
            <motion.div 
              key="templates"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8"
            >
              <div className="text-center space-y-2">
                <h2 className="text-3xl font-bold text-white">Escolha o seu Modelo</h2>
                <p className="text-slate-400 text-lg">Modelos optimizados para destacar as tuas competências práticas e teóricas.</p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {templates.map((t) => (
                  <div 
                    key={t.id}
                    className={`bg-slate-800 rounded-2xl overflow-hidden border-2 border-transparent transition-all hover:border-blue-500 group relative shadow-xl`}
                  >
                    <div className="aspect-[3/4] overflow-hidden bg-slate-700">
                      <img 
                        src={t.image} 
                        alt={t.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform opacity-80 group-hover:opacity-100"
                      />
                    </div>
                    <div className="p-4 space-y-2">
                      <h3 className="font-bold text-white">{t.name}</h3>
                      <p className="text-xs text-slate-400 leading-tight">{t.desc}</p>
                      <button 
                        onClick={() => selectTemplate(t.id)}
                        className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors"
                      >
                        Usar este Modelo
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="text-center">
                <button onClick={() => setView('home')} className="bg-slate-800 text-white px-6 py-2 rounded-full border border-slate-700 hover:bg-slate-700 transition-colors">Voltar ao Início</button>
              </div>
            </motion.div>
          )}

          {view === 'interview' && (
            <motion.div 
              key="interview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl mx-auto h-[75vh] flex flex-col bg-slate-800 rounded-3xl border border-slate-700 shadow-2xl overflow-hidden"
            >
              {/* Chat Header */}
              <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between border-b border-slate-800">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${personas[selectedPersona].color} rounded-xl flex items-center justify-center text-white shadow-lg`}>
                    {personas[selectedPersona].icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm tracking-tight">{personas[selectedPersona].name}</h3>
                    <p className="text-[10px] text-blue-400 uppercase tracking-widest font-black">{personas[selectedPersona].role}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setView('home')} 
                  className="flex items-center text-xs font-bold text-slate-400 hover:text-white transition-colors bg-white/5 px-4 py-2 rounded-xl border border-white/10"
                >
                  <ArrowRight className="w-4 h-4 mr-2 rotate-180" /> Sair
                </button>
              </div>

              {/* Messages Area */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-900/50">
                {messages.map((msg, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    key={idx} 
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex space-x-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center mt-1 shadow-md ${
                        msg.role === 'user' ? 'bg-blue-600 text-white' : `${personas[selectedPersona].color} text-white`
                      }`}>
                        {msg.role === 'user' ? <User className="w-4 h-4" /> : personas[selectedPersona].icon}
                      </div>
                      <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                        msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-slate-800 text-slate-100 border border-slate-700 rounded-tl-none'
                      }`}>
                        <div className={`prose prose-sm max-w-none ${msg.role === 'user' ? 'prose-invert' : 'prose-invert text-slate-200'}`}>
                          <ReactMarkdown>
                            {msg.parts[0].text}
                          </ReactMarkdown>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                {isLoading && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <div className="bg-slate-800 border border-slate-700 p-4 rounded-2xl rounded-tl-none flex items-center space-x-3 shadow-lg">
                      <div className="flex space-x-1">
                        <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                        <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                        <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                      </div>
                      <span className="text-xs text-slate-400 font-medium">{personas[selectedPersona].name.split(' ')[0]} está analisando...</span>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Input Area */}
              <div className="p-4 bg-slate-900 border-t border-slate-800">
                <div className="flex items-center space-x-2 bg-slate-800 rounded-2xl px-4 py-1.5 border border-slate-700 shadow-inner">
                  <input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendInterview()}
                    placeholder="Escreve a tua resposta..."
                    className="flex-1 bg-transparent border-none outline-none text-sm py-3 text-white placeholder:text-slate-500"
                  />
                  <button 
                    disabled={!input.trim() || isLoading}
                    onClick={handleSendInterview}
                    className="p-3 bg-blue-600 text-white rounded-xl disabled:opacity-30 hover:bg-blue-700 shadow-lg shadow-blue-900/20 transition-all"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'payment' && (
            <motion.div 
              key="payment"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-md mx-auto bg-white rounded-3xl p-8 border border-slate-200 shadow-2xl text-center space-y-6"
            >
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto">
                <CreditCard className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold">Quase lá!</h2>
              <p className="text-slate-600">
                Pague apenas **500 MT** para receber seu CV totalmente otimizado, revisado por nossa IA e com as palavras-chave certas para passar nos filtros de RH.
              </p>
              <div className="space-y-3">
                <button className="w-full bg-[#f68b1e] text-white py-4 rounded-xl font-bold flex items-center justify-center hover:brightness-110 transition-all">
                  Pagar com M-Pesa
                </button>
                <button className="w-full bg-[#00adef] text-white py-4 rounded-xl font-bold flex items-center justify-center hover:brightness-110 transition-all">
                  Pagar com e-Mola
                </button>
              </div>
              <button onClick={() => setView('cv-check')} className="text-slate-400 text-sm hover:underline">Voltar para análise</button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="bg-slate-950 border-t border-slate-900 py-12 px-6 mt-20">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Briefcase className="w-6 h-6 text-blue-600" />
              <span className="font-bold text-lg text-white">Walter JobPrep</span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed">
              Capacitando Moçambicanos para o mercado de trabalho global e local com tecnologia de ponta.
            </p>
          </div>
          <div>
            <h4 className="font-bold text-white mb-4">Serviços</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><button onClick={() => setView('cv-check')} className="hover:text-blue-400">Análise de CV</button></li>
              <li><button onClick={() => setView('select-company')} className="hover:text-blue-400">Simulação por Empresa</button></li>
              <li><button onClick={() => setView('templates')} className="hover:text-blue-400">Modelos de Currículo</button></li>
              <li><button onClick={() => setView('home')} className="hover:text-blue-400">Treino Psicológico</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-white mb-4">Recursos Úteis</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><a href="https://mmo.co.mz/vagas-de-emprego" target="_blank" className="hover:text-blue-400 flex items-center">MMO Emprego <ExternalLink className="w-3 h-3 ml-1" /></a></li>
              <li><a href="https://oemprego.co.mz" target="_blank" className="hover:text-blue-400 flex items-center">O Emprego <ExternalLink className="w-3 h-3 ml-1" /></a></li>
              <li><a href="https://www.linkedin.com/jobs/jobs-in-mozambique" target="_blank" className="hover:text-blue-400 flex items-center">LinkedIn Moz <ExternalLink className="w-3 h-3 ml-1" /></a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-white mb-4">Suporte</h4>
            <p className="text-sm text-slate-500 mb-4">Precisas de ajuda personalizada?</p>
            <a 
              href="https://wa.me/258XXXXXXXXX" 
              className="inline-flex items-center bg-emerald-600/10 text-emerald-500 border border-emerald-500/20 px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-600 hover:text-white transition-all"
            >
              Contactar Equipa Walter
            </a>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-slate-900 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-600 gap-4">
          <p>© 2026 Walter JobPrep Moçambique. Todos os direitos reservados.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-white">Termos de Uso</a>
            <a href="#" className="hover:text-white">Privacidade</a>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating */}
      <a 
        href="https://wa.me/258XXXXXXXXX" 
        className="fixed bottom-6 right-6 bg-emerald-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform z-50"
        title="Ajuda via WhatsApp"
      >
        <MessageSquare className="w-6 h-6" />
      </a>
    </div>
  );
}

function FeatureCard({ icon, title, desc, dark = false }: { icon: React.ReactNode, title: string, desc: string, dark?: boolean }) {
  return (
    <div className={`${dark ? 'bg-slate-800/40 border-slate-700 text-white shadow-xl hover:bg-slate-800/60' : 'bg-white border-slate-100 text-slate-900 shadow-sm'} p-6 rounded-2xl border transition-all space-y-4`}>
      <div className={`w-12 h-12 ${dark ? 'bg-slate-900' : 'bg-slate-50'} rounded-xl flex items-center justify-center`}>
        {icon}
      </div>
      <h3 className="font-bold">{title}</h3>
      <p className={`${dark ? 'text-slate-400' : 'text-slate-500'} text-sm leading-relaxed`}>{desc}</p>
    </div>
  );
}
