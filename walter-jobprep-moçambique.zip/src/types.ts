export interface DailyEntry {
  id: string;
  date: string;
  mood: 'great' | 'good' | 'meh' | 'bad' | 'terrible';
  cravingLevel: number; // 0-10
  notes: string;
}

export interface UserStats {
  sobrietyStartDate: string | null;
  totalDays: number;
  longestStreak: number;
}
