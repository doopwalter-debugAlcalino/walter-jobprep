import { CareerPortal } from './components/CareerPortal';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <CareerPortal />
    </div>
  );
}
